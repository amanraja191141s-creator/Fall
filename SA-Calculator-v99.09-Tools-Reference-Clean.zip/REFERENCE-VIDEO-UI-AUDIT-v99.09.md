# SA Calculator v99.09 — Tools catalogue reference audit

## Reference source
- User-uploaded screen recording: `Screenrecording_20261125_115925.mp4`
- Duration: 94.96 seconds; sampled at 2-second intervals, with detailed inspection of the Tools catalogue and tool workspaces.
- Reference catalogue: 3 groups and 12 launchers.

## Required catalogue
- Finance & Money (8): GST/VAT, Loan, Saving, Salary, Tip, SIP, Currency, Discount.
- Math & General Utilities (2): Percentage, Unit.
- Health (2): Age, BMI.

## Changes in this refresh
- Replaced generic text/emoji launcher marks with 12 consistent, inline white line-art SVG icons inspired by the recording.
- Preserved the three-column catalogue, group order, dark canvas, rounded dark cards, compact labels and scroll behavior.
- Kept exactly the 12 launchers shown in the recording; no additional tool launcher is exposed.
- Preserved the 12 corresponding calculator/converter workspaces, shared keypad, favorites/search registry, and calculation systems.
- Added a regression assertion for exact launcher count, labels, SVG count and line-icon styling.
- Rebuilt `www/` from authoritative source files and synchronized the standalone Android workflow with `.github/workflows/main.yml`.

## Measured layout values
- Catalogue grid: 3 equal columns.
- Tool card: 98 CSS px fixed height (90 CSS px on narrow/short viewports).
- Card corner radius: 14 CSS px.
- Grid gaps: 8 CSS px horizontal, 20 CSS px vertical.
- Icon viewport: 40 × 40 CSS px.
- Screen gutter: 12 CSS px.
- Section heading: 18 CSS px.
- Tool label: 16 CSS px.

## Verification
- All 63 release/regression tests pass.
- JavaScript syntax checks pass.
- Web bundle preparation passes and root/www mirrors are byte-identical.
- ZIP archive integrity is checked after packaging.
- The Android APK build and physical-device touch/pixel comparison remain external checks; they are not claimed as completed here.
