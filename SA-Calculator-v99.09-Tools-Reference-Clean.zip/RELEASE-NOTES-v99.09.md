# SA Calculator v99.09 — Release notes

- Tools catalogue aligned to the supplied 2026-11-25 reference recording.
- Exactly 12 tools retained across Finance & Money, Math & General Utilities, and Health.
- Twelve custom inline line-art launcher icons replace generic emoji/text symbols.
- Existing tool workspaces, shared numeric keypad, favorites, search registry and calculator engine preserved.
- Added catalogue count, label and icon regression coverage.
- Android workflow and standalone YAML synchronized.
- Android APK build and real-device validation still require GitHub Actions/device execution.
