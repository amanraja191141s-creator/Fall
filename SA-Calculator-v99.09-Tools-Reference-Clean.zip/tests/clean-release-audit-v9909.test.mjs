import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=p=>fs.readFileSync(p,'utf8');
const base=read('assets/css/app.css');
const ui=read('assets/css/tool-reference-ui.css');
const html=read('index.html');
const js=read('assets/js/app.js');
const pkg=JSON.parse(read('package.json'));
const workflow=read('.github/workflows/main.yml');

test('release identity and cache namespace are synchronized',()=>{
  const v='1.99.23-v99.09';
  assert.equal(pkg.version,v); assert.equal(pkg.androidVersionCode,1099138);
  assert.ok(html.includes(v)); assert.ok(js.includes(`const APP_VERSION = '${v}'`));
  assert.equal(JSON.parse(read('manifest.webmanifest')).version,v);
  assert.match(read('service-worker.js'),/^const CACHE='sa-calculator-v99-09-clean-release-v9909'/m);
  assert.ok(workflow.includes(`SA_EXPECTED_VERSION: '${v}'`));
});
test('base CSS no longer carries superseded appended visual layers',()=>{
  for(const marker of ['v98.12 — premium Android safe-area','v98.13 — complete adaptive','v98.15 — complete premium','v98.18 HARD REFERENCE SKIN']) assert.equal(base.includes(marker),false,marker);
  assert.ok(base.includes('SA CALCULATOR v98.17 — FULL REFERENCE REBUILD'));
  assert.ok(base.includes('v98.19 — NATIVE PREMIUM DARK REFERENCE SYSTEM'));
});
test('tool UI stylesheet contains only the consolidated current reference layer',()=>{
  assert.ok(ui.startsWith('/* v99.09 — consolidated single-source reference UI'));
  for(const marker of ['v98.20','v98.21','v98.23','v98.24','v98.25','v98.26','v98.27','v99.04','v99.06','v99.07']) assert.equal(ui.includes(marker),false,marker);
  assert.match(ui,/grid-template-columns:repeat\(3,minmax\(0,1fr\)\)/);
  assert.match(ui,/bottom:0/);
  assert.match(ui,/body\.tool-keypad-active/);
});
test('keypad missing-dock path cannot mutate focus or browser history',()=>{
  const body=js.slice(js.indexOf('function openToolKeypad('),js.indexOf('function closeToolKeypad('));
  assert.ok(body.indexOf("const sheet = document.getElementById('tool-keypad-dock')") < body.indexOf('window.history.pushState'));
  assert.ok(body.indexOf("if (!sheet) return") < body.indexOf('window.history.pushState'));
  assert.equal((body.match(/sheet\.setAttribute\('aria-hidden', 'false'\)/g)||[]).length,1);
});
test('only requested 12 tool workspaces remain and root/web assets match',()=>{
  const ids=[...html.matchAll(/id="screen-([a-z]+)"/g)].map(m=>m[1]);
  for(const id of ['salestax','loan','savings','salary','tip','sip','currencies','discount','percent','units','agecalc','bodymetrics']) assert.ok(ids.includes(id),`missing ${id}`);
  for(const p of ['index.html','assets/css/app.css','assets/css/tool-reference-ui.css','assets/js/app.js','service-worker.js']) assert.equal(read(p),read(`www/${p}`),`${p} differs from www`);
});
test('release package no longer contains stale versioned root reports or YAML files',()=>{
  const names=fs.readdirSync('.');
  assert.deepEqual(names.filter(x=>/^BUILD-VERIFICATION-v98|^RELEASE-NOTES-v98|^REFERENCE-VIDEO-.*v99\.0[4-8]|^sa-calculator-v99\.0[78]-android\.yml$/.test(x)),[]);
  assert.ok(fs.existsSync('REFERENCE-VIDEO-UI-AUDIT-v99.09.md'));
  assert.ok(fs.existsSync('BUILD-VERIFICATION-v99.09.md'));
  assert.ok(fs.existsSync('RELEASE-NOTES-v99.09.md'));
});
test('workflow test entry points all exist and are in npm release suite',()=>{
  const cmd=pkg.scripts['test:release'];
  const tests=[...cmd.matchAll(/(?:^|\s)(tests\/[^\s]+)/g)].map(m=>m[1]);
  assert.ok(tests.length>=9);
  for(const f of tests) assert.ok(fs.existsSync(f),`missing ${f}`);
  assert.ok(workflow.includes("'tests/clean-release-audit-v9909.test.mjs'"));
});
